# Fire detection using yolov5 > 2023-11-29 2:53pm
https://universe.roboflow.com/college-jnfdd/fire-detection-using-yolov5

Provided by a Roboflow user
License: CC BY 4.0

